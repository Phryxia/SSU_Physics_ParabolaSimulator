import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ParabolaSimulation extends PApplet {

final float[] BUTTON = {0, 0};
Ball myBall;

/*
  Experiment Condition
*/
float wind_v    = 0;  // m/s
float wind_dir  = 0; // rad
final float g = 9.81f;

float x_ini;
float y_ini;
boolean isFlying = false;
boolean isDrag = false;

float pix_per_met = 100;
float[] x_pos = new float[1024];
float[] y_pos = new float[1024];
int     pos_size = 0;
int T_RES = 1000;

int mode = 0; // 0 = No Resistance, 1 = Air, 2 = Water

boolean pressedControl = false;

public void setup()
{
  size(800, 600);
  colorMode(HSB, 1.0f);
  background(0);
  
  x_ini = width/8;
  y_ini = height/2;
  
  myBall = new Ball();
  myBall.changeSize(1, 7860);
  reset();
  
  frameRate(120);
}

float F, D, Theta;
int t = 0;

public void draw()
{
  /*
    Graphic Output
  */
  background(0);
  if(mode > 0)
  {
    drawWind();
  }
  
  // Text
  textSize(14);
  text("Fluid  Speed : "+PApplet.parseInt(100*wind_v)/100.0f+"m/s", 20, 20);
  text("Object Speed : "+PApplet.parseInt(100*dist(0, 0, myBall._vx, myBall._vy))/100.0f+"m/s", 20+width/4, 20);
  text("Object Mass  : "+PApplet.parseInt(100*myBall.m)/100.0f+"kg", 20, 40);
  text("Object Size  : "+PApplet.parseInt(100*myBall.r)/100.0f+"m", 20+width/4, 40);
  text("Object Dens  : "+PApplet.parseInt(100*myBall.rho)/100.0f+"kg/m^3", 20+width/2, 40);
  textSize(12);
  text("[m] : Mode Change        [SPACE] : RESET", 20, height-40); 
  text("[LEFT, RIGHT] Fluid Direction   [UP, DOWN] Fluid Speed   [Wheel] Object Mass   [CTRL+Wheel] Object Density", 20, height-20);
  String temp = "";
  switch(mode)
  {
    case 0:
      temp = "Mode : No Resistance";
      break;
    case 1:
      temp = "Mode : Air @ 25 C";
      break;
    case 2:
      temp = "Mode : Water @ 25 C";
      break;
  }
  text(temp, width-textWidth(temp)-20, 20);
  
  // Previous Ball
  noStroke();
  fill(0, 1, 0.5f);
  for(int i=0; i<pos_size; ++i)
  {
    ellipse(x_pos[i]*pix_per_met, height - y_pos[i]*pix_per_met, 4, 4);
  }
  
  // Current Ball
  myBall.render();
  
  if(isFlying)
  {
    // Calculation & Assign New Value
    for(int d=0; d<T_RES; ++d) // Enhancing Time Resolution
    {
      // Fluid Resistance
      float fluid_S = 4*myBall.r*myBall.r*PI;
      float fluid_rho = 0.0f; // Density
      float fluid_cd  = 0.7f; // Sphere Type Constant
      switch(mode)
      {
        case 0: // NONE
          fluid_rho = 0.0f;
          break;
        case 1:
          fluid_rho = 1.184f; // Air Resistance
          break;
        case 2:
          fluid_rho = 997.0479f; // Water Resistance
          break;
      }
      
      float x_resist = 0.5f*fluid_rho*fluid_S*pow(abs(myBall._vx - wind_v*cos(wind_dir)), 2);
      float y_resist = 0.5f*fluid_rho*fluid_S*pow(abs(myBall._vy - wind_v*sin(wind_dir)), 2);
      
      // Resistance Direction
      if(myBall._vx - wind_v*cos(wind_dir) > 0)
      {
        x_resist *= -1;
      }
      if(myBall._vy - wind_v*sin(wind_dir) > 0)
      {
        y_resist *= -1;
      }
      
      // Fluid Buoyancy
      float buoyancy = g*(fluid_rho*4/3*PI*pow(myBall.r, 3));
      
      // Final Calculation
      myBall.tick(x_resist, -g*myBall.m+y_resist+buoyancy, 1.0f/frameRate/T_RES);
    }
    if(pos_size < x_pos.length-1 && t%10 == 0)
    {
      x_pos[pos_size] = myBall._x;
      y_pos[pos_size] = myBall._y;
      ++pos_size;
    }
  }
  else
  {
    textSize(40);
    text("Drag the Object!", width/2 - textWidth("Drag the Object!")/2, height/2);
    
    // Drag Motion : Determine Default Speed
    if(isDrag)
    {
      strokeWeight(2);
      stroke(0, 1, 0.5f);
      
      D = dist(x_ini, y_ini, mouseX, mouseY);
      Theta = atan2(y_ini-mouseY, x_ini-mouseX);
      
      float v_temp = 0.1f*D*sqrt(1.0f/myBall.m);
      
      drawArrow(x_ini, y_ini, D, -Theta);
      textSize(10);
      text(PApplet.parseInt(v_temp*100)/100.0f+"m/s", mouseX - 20, mouseY - 20);
      
      //line(x_ini, y_ini, mouseX, mouseY);
      strokeWeight(1);
    }
  }
  
  ++t;
}

public void mousePressed()
{
  isDrag = true;
}

public void mouseReleased()
{
  isDrag = false;
  
  if(!isFlying)
  {
    float v_temp = 0.1f*D*sqrt(1.0f/myBall.m);
    myBall._vx = v_temp*cos(Theta);
    myBall._vy = v_temp*sin(Theta+PI);
    isFlying = true;
  }
}

public void mouseWheel(MouseEvent event)
{
  float delta = event.getCount();
  
  if(!pressedControl)
  {
    // Mass Control{
    if(myBall.m + delta > 0)
    {
      myBall.m += delta;
    }
  }
  else
  {
    // Rho Control
    if(myBall.rho*exp(-delta*0.5f) > 0.01f)
    {
      myBall.rho *= exp(-delta*0.5f);
    }
  }
  myBall.changeSize(myBall.m, myBall.rho);
}

public void keyPressed()
{
  if(key != CODED)
  {
    if(key == ' ')
    {
      // Reset
      reset();
    }
    else if(key == 'm')
    {
      // Mode Change
      switch(mode)
      {
        case 0:
          println("Mode has been changed into AIR");
          break;
        case 1:
          println("Mode has been changed into WATER");
          break;
        case 2:
          println("Mode has been changed into NO RESISTANCE");
          break;
      }
      mode = (mode+1)%3;
    }
  }
  else
  {
    // Wind Direction Change
    if(keyCode == LEFT)
    {
      wind_dir += PI/90;
    }
    if(keyCode == RIGHT)
    {
      wind_dir -= PI/90;
    }
    if(keyCode == DOWN)
    {
      if(wind_v > 0)
      {
        wind_v -= 0.1f;
      }
    }
    if(keyCode == UP)
    {
      wind_v += 0.1f;
    }
    if(keyCode == CONTROL)
    {
      pressedControl = true;
    }
  }
}

public void keyReleased()
{
  pressedControl = false;
}

public void reset()
{
  myBall._x = x_ini/pix_per_met;
  myBall._y = y_ini/pix_per_met;
  myBall._vx = 0.0f;
  myBall._vy = 0.0f;
  myBall._ax = 0.0f;
  myBall._ay = 0.0f;
  
  isFlying = false;
  pos_size = 0;
}

public void drawWind()
{
  stroke(0.6f, 1, 1);
  for(int y=0; y<10; ++y)
  {
    for(int x=0; x<10; ++x)
    {
      int wind_x = PApplet.parseInt(x/10.0f*width);
      int wind_y = PApplet.parseInt(y/10.0f*height);
      
      drawArrow(wind_x, wind_y, 10.0f*wind_v, wind_dir);
    }
  }
}

public void drawArrow(float _x, float _y, float _length, float theta)
{
  pushMatrix();
  translate(_x, _y);
  rotate(-theta);
  line(0, 0, -_length, 0);
  line(0, 0, -5*cos(PI/4), -5*sin(PI/4));
  line(0, 0, -5*cos(PI/4),  5*sin(PI/4));
  popMatrix();
}
class Ball
{
  public float _x;
  public float _y;
  public float _vx = 0.0f, _vy = 0.0f;
  public float _ax = 0.0f, _ay = 0.0f;
  public int _c = color(0, 1, 1);
  
  public float m;
  public float r;
  public float rho;
  
  public void changeSize(float mass, float dens)
  {
    m = mass;
    rho = dens;
    r = pow(0.75f/PI*m/rho, 0.333f);
  }
  
  public void render()
  {
    noStroke();
    fill(_c);
    ellipse(_x*pix_per_met, height-_y*pix_per_met, r*pix_per_met, r*pix_per_met);
  }
  
  public void tick(float Fx, float Fy, float dt)
  {
    _ax = Fx/m;
    _ay = Fy/m;
    _x  += dt*_vx+0.5f*dt*dt*_ax;
    _y  += dt*_vy+0.5f*dt*dt*_ay;
    _vx += dt*_ax;
    _vy += dt*_ay;
  }
}

static class Util
{
  public static boolean isBounded(float x, float y, float w, float h)
  {
    return x>=0 && x<w && y>=0 && y<h;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ParabolaSimulation" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
